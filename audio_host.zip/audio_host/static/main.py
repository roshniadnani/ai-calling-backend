from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

app = FastAPI()

# Serve files from the /static folder at the root URL
app.mount("/", StaticFiles(directory="static", html=True), name="static")
